const firebaseConfig = {
  apiKey: "AIzaSyBl2UWkexB8oLRHlM9qbLY0NjBbPEZct3Q",
  authDomain: "mediconnect-513bd.firebaseapp.com",
  projectId: "mediconnect-513bd",
  appId: "1:707521311839:web:9eb7a6bbfc62db153797ea"
};

firebase.initializeApp(firebaseConfig);

const signupForm = document.getElementById("signupForm");
if (signupForm) {
  signupForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("fullName").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }
    firebase.auth().createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
        return userCredential.user.updateProfile({ displayName: name });
      })
      .then(() => {
        window.location.href = "https://v0-gemini-health-support-page.vercel.app/";
      })
      .catch((error) => {
        alert("Signup Error: " + error.message);
      });
  });
}

const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;
    firebase.auth().signInWithEmailAndPassword(email, password)
      .then(() => {
        window.location.href = "https://v0-gemini-health-support-page.vercel.app/";
      })
      .catch((error) => {
        alert("Login Error: " + error.message);
      });
  });
}